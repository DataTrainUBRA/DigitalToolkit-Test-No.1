---
title: Curriculum
nav_order: 3
---

# **Content:**


## Data Science
- Statistisches & kritisches Denken
- Methoden inkl. KI-Verfahren

## Research Data Management (RDM)
- FAIR-Prinzipien
- Datenschutz & Urheberrecht
- Umgang mit sensiblen & qualitativen Daten

## Programmierung
- Python, R, weitere Sprachen
- Datenhandling & Engineering

## Visualisierung
- Best Practices
- Tools & Plattformen
