# Digital Toolkit Test No.1
Our first try to set up a curated collection of new and existing digital self-learning materials to make learning more comftable and indipendent.
Lecturers have limited time. Learners have diverse knowledge.


This is why we would like to provide:
- 	Fewer but better resources, not many scattered
- 	A patform that is easy to find and easy to use - open access
- 	The oppertunity to chose the own learning path



