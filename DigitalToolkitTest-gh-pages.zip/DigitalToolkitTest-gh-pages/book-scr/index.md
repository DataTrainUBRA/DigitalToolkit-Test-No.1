# Hello World

We're sorry, but this website is under construction. Content and structure will be added gradually.

## Future content fields

- Data Science
- Data Analysis
- Research Data Management (RDM):
  - FAIR data principles
  - Data protection, copyright, sensitive data
- Programming
- Data visualization
- Data handling, Data engineering
- Methods and techniques (also AI)
- Statistical thinking, Critical thinking
- einiges mehr
- noch viel viel mehr

